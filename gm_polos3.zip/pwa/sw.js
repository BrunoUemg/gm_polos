self.addEventListener('fetch', () => {
  // literally does nothing
});

//console.info('SW for test running');
