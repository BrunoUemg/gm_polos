
# FullCalendar Resource Day Grid Plugin

Displays events in individual columns for days and resources

[View the docs &raquo;](https://fullcalendar.io/docs/resource-daygrid-view)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar-scheduler)
